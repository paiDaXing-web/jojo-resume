Page({
  data: {
  
  },
  getTospace(){
    wx.navigateTo({
      url:'/pages/chat/chat'
    });
  },
  getTomyEarth(){
    wx.navigateTo({
      url:'/pages/myEarth/myEarth'
    });
  },
  onLoad() {
   
  },
})
